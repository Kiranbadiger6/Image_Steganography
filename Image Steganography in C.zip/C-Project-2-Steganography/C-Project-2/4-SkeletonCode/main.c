#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include<string.h>
#include "types.h"

OperationType check_operation_type(char *argv)
{
    if(strcmp(argv, "-e") == 0)
    {
        return e_encode;
    }
    else if(strcmp(argv, "-d") == 0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}

int main(int argc, char *argv[])
{
    
    OperationType res = check_operation_type(argv[1]);

    if(res == e_encode)
    {
        EncodeInfo encInfo;
        //validation
        if(read_and_validate_encode_args(argv, &encInfo,argc) == e_success)
        {
            //do encoding
            if(do_encoding(&encInfo) == e_failure)
            {
                printf("Error : your encoding failed\n");
                return 0;
            }
            else
            {
                printf("Your Encoding is successfully completed.\n");
                return 0;
            }

        }
        else
        {
            printf("Error : your encoding failed\n");
            return 0; 
        }
    }
    else if(res == e_decode)
    {
        DecodeInfo decInfo;

       {
    
        if (read_and_validate_decode_args(argv, &decInfo) == e_success)
            {
                printf("INFO: Selected Decoding\n");

                if (do_decoding(&decInfo) == e_success)
                {
                    printf("INFO: Decoding Successful\n");
                }
                else
                {
                    printf("ERROR: Decoding Failed\n");
                }
            }
        else
            {
                printf("ERROR: Invalid arguments for decoding\n");
            }
        }
    }
    else
    {
        // print error
        printf("ERROR: Invalid Decoding Arguments\n");
        // exit
    }
    return 0;
}
