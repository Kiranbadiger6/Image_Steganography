#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"      // For Status
#include "common.h"     // For MAGIC_STRING

typedef struct _DecodeInfo
{
    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

    /* Output Secret File Info */
    char output_fname[50];
    FILE *fptr_output;

    /* Secret File Extension */
    char extn_secret_file[20];
    int extn_size;

    /* Secret File Size */
    int size_secret_file;

} DecodeInfo;


/* Read and validate command line arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* Open required files */
Status open_decode_files(DecodeInfo *decInfo);

/* Perform complete decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Decode magic string */
Status decode_magic_string(DecodeInfo *decInfo);

/* Decode one character from 8 bytes */
char decode_byte_from_lsb(char *image_buffer);

/* Decode integer from 32 bytes */
int decode_size_from_lsb(char *image_buffer);

/* Decode extension size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo);

/* Decode extension */
Status decode_secret_file_extn(DecodeInfo *decInfo);

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo);

#endif