#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "decode.h"
#include "common.h"
#include "types.h"

/* Read and validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    /* Stego image file */
    if (argv[2] != NULL)
    {
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        printf("ERROR: Stego image file not provided\n");
        return e_failure;
    }

    /* Output file name (optional) */
    if (argv[3] != NULL)
    {
        strcpy(decInfo->output_fname, argv[3]);
    }
    else
    {
        /* Default name; extension will be appended after decoding */
        strcpy(decInfo->output_fname, "output");
    }

    return e_success;
}


/* Open required files */
Status open_decode_files(DecodeInfo *decInfo)
{
    /* Open stego image */
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "rb");

    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n",
                decInfo->stego_image_fname);
        return e_failure;
    }

    return e_success;
}


/* Perform decoding */
Status do_decoding(DecodeInfo *decInfo)
{
    printf("INFO: Opening required files\n");

    if (open_decode_files(decInfo) == e_failure)
    {
        printf("ERROR: Failed to open files\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    /* Skip BMP Header */
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);

    printf("INFO: Decoding Magic String Signature\n");

    if (decode_magic_string(decInfo) == e_failure)
    {
        printf("ERROR: Magic String Mismatch\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    printf("INFO: Decoding Secret File Extension Size\n");

    if (decode_secret_file_extn_size(decInfo) == e_failure)
    {
        printf("ERROR: Failed\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    printf("INFO: Decoding Secret File Extension\n");

    if (decode_secret_file_extn(decInfo) == e_failure)
    {
        printf("ERROR: Failed\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    printf("INFO: Decoding Secret File Size\n");

    if (decode_secret_file_size(decInfo) == e_failure)
    {
        printf("ERROR: Failed\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    printf("INFO: Decoding Secret File Data\n");

    if (decode_secret_file_data(decInfo) == e_failure)
    {
        printf("ERROR: Failed\n");
        return e_failure;
    }

    printf("INFO: Done\n");

    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_output);

    return e_success;
}

/* Decode one character from 8 bytes */
char decode_byte_from_lsb(char *image_buffer)
{
    char ch = 0;

    for (int i = 0; i < 8; i++)
    {
        ch = (ch << 1) | (image_buffer[i] & 1);
    }

    return ch;
}

/* Decode an integer from 32 bytes */
int decode_size_from_lsb(char *image_buffer)
{
    int size = 0;

    for (int i = 0; i < 32; i++)
    {
        size = (size << 1) | (image_buffer[i] & 1);
    }

    return size;
}
/* Decode Magic String */
Status decode_magic_string(DecodeInfo *decInfo)
{
    char image_buffer[8];
    char magic_str[3];

    for (int i = 0; i < strlen(MAGIC_STRING); i++)
    {
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image);
        magic_str[i] = decode_byte_from_lsb(image_buffer);
    }

    magic_str[strlen(MAGIC_STRING)] = '\0';

    if (strcmp(magic_str, MAGIC_STRING) == 0)
    {
        return e_success;
    }

    return e_failure;
}

/* Decode secret file extension size */
Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    char image_buffer[32];

    fread(image_buffer, 1, 32, decInfo->fptr_stego_image);

    decInfo->extn_size = decode_size_from_lsb(image_buffer);

    printf("Extension size = %d\n", decInfo->extn_size);

    return e_success;
}
/* Decode secret file extension */
Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    char image_buffer[8];

    for (int i = 0; i < decInfo->extn_size; i++)
    {
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image);
        decInfo->extn_secret_file[i] = decode_byte_from_lsb(image_buffer);
        
    }

    decInfo->extn_secret_file[decInfo->extn_size] = '\0';

    /* Append extension to output filename */
    strcat(decInfo->output_fname, decInfo->extn_secret_file);

    decInfo->fptr_output = fopen(decInfo->output_fname, "wb");

    if (decInfo->fptr_output == NULL)
    {
        perror("fopen");
        printf("ERROR: Unable to create output file %s\n",
               decInfo->output_fname);
        return e_failure;
    }

    return e_success;
}

/* Decode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char arr[32];

    fread(arr, 1, 32, decInfo->fptr_stego_image);

    decInfo->size_secret_file = decode_size_from_lsb(arr);

    printf("File size = %d\n", decInfo->size_secret_file);

    return e_success;
}


/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char image_buffer[8];
    char ch;

    for (int i = 0; i < decInfo->size_secret_file; i++)
    {
        fread(image_buffer, 8, 1, decInfo->fptr_stego_image);

        ch = decode_byte_from_lsb(image_buffer);

        fwrite(&ch, 1, 1, decInfo->fptr_output);
    }

    return e_success;
}